﻿namespace ClassLibrary1
{
    public class Class1
    {
        // имя продукта
        static string NameProduct { get; set; }

        // белок
        static int Protein { get; set; }

        // углеводы
        static int Carbohydrates { get; set; }

        public Class1(string nameProduct, int protein, int carbohydrates)
        {
            NameProduct = nameProduct;
            Protein = protein;
            Carbohydrates = carbohydrates;
        }

        public virtual double Q()
        {
            return Carbohydrates * 4 + Protein * 4;
        }

        public virtual string Info()
        {
            if (string.IsNullOrEmpty(NameProduct))
                return "error";
            else if (Protein < 1)
                return "error";
            else if (Carbohydrates < 1)
                return "error";
            else
                return $"{NameProduct}, {Protein}, {Carbohydrates}, {Q():F2}";
        }

        public virtual void PrintInfo()
        {
            if (string.IsNullOrEmpty(NameProduct))
                Console.WriteLine("error");
            else if (Protein < 1)
                Console.WriteLine("error");
            else if (Carbohydrates < 1)
                Console.WriteLine("error");
            else
                Console.WriteLine($"{NameProduct}, {Protein}, {Carbohydrates}, {Q():F2}");
        }
    }
}
