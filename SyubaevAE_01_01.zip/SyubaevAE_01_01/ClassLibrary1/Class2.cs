﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class2 : Class1
    {
        // жиров в продукте
        static int P { get; set; }

        public Class2(string nameProduct, int protein, int carbohydrates, int p)
            : base (nameProduct, protein, carbohydrates)
        {
            P = p;
        }

        public override double Q()
        {
            double baseQ = base.Q();

            if (P >= 0 && P <= 10)
                return baseQ * 1.1 + P * 9;
            else if (P > 10)
                return baseQ * 1.3 + P * 10;
            else
                return baseQ;
        }
    }
}
