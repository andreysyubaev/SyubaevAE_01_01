﻿using System.IO;
using ClassLibrary1;

// имя продукта
string NameProduct;

// белок
int Protein;

// углеводы
int Carbohydrates;

// количество жиров
int p;

int choice;

do
{
    Console.WriteLine("1 - ввести значения с клавиатуры\n2 - показать фиксированные значения\n0 - выйти");
    choice = int.Parse(Console.ReadLine());
    if (choice == 1)
    {
        Console.Write("имя продукта: ");
        NameProduct = Console.ReadLine();

        Console.Write("кол-во протеина (г): ");
        Protein = int.Parse(Console.ReadLine());

        Console.Write("кол-во углеродов (г): ");
        Carbohydrates = int.Parse(Console.ReadLine());

        var a = new Class1(NameProduct, Protein, Carbohydrates);
        a.PrintInfo();

        Console.Write("кол-во жиров (г): ");
        p = int.Parse(Console.ReadLine());

        var b = new Class2(NameProduct, Protein, Carbohydrates, p);
        b.PrintInfo();
    } 
    else if (choice == 2)
    {
        // имя продукта - product1, белков - 20, углеводов - 30
        var a = new Class1("product1", 20, 30);
        a.PrintInfo();
        // product1, 20, 30, 200,00

        // имя продукта - product1, белков - 20, углеводов - 30, жиров - 10
        var b = new Class2("product2", 20, 30, 10);
        b.PrintInfo();
        // product2, 20, 30, 310,00

        // имя продукта - product1, белков - 20, углеводов - 30, жиров - 5
        b = new Class2("product3", 20, 30, 5);
        b.PrintInfo();
        // product2, 20, 30, 265,00
    }
} while (choice != 0);
